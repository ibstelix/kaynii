var test = (function() {
    
    
    return{
        getInstance: function () {
            
        }
    };
})();